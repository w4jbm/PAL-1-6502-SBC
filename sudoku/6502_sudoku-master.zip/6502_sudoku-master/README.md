# 6502_sudoku
Sudoku solver in 6502 assembler
